# Red Storm Tools Suite Documentation

This directory contains documentation and assets for the Red Storm Tools Suite GitHub Pages site.

## Structure
- `/docs/assets/images/` - Aircraft silhouette images for print sheets
- Additional documentation files may be added here in the future

## GitHub Pages
This follows the standard GitHub Pages documentation structure recommended for Jekyll sites.